import { useMemo } from "react";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { BarChart, Bar, Legend } from "recharts";
import "./App.css";

const overview = [
  { label: "Receita Mensal", value: "R$ 482.000", delta: "+12% vs mês anterior", tone: "green" },
  { label: "Pedidos fechados", value: "1.240", delta: "+8% vs previsão", tone: "green" },
  { label: "Ticket médio", value: "R$ 388", delta: "Estável", tone: "neutral" },
];

const trendData = [
  { month: "Jan", revenue: 320000, margin: 42 },
  { month: "Fev", revenue: 360000, margin: 44 },
  { month: "Mar", revenue: 420000, margin: 46 },
  { month: "Abr", revenue: 430000, margin: 43 },
  { month: "Mai", revenue: 458000, margin: 45 },
  { month: "Jun", revenue: 482000, margin: 47 },
];

const regionData = [
  { region: "Sudeste", value: 54 },
  { region: "Sul", value: 18 },
  { region: "Nordeste", value: 16 },
  { region: "Centro-Oeste", value: 7 },
  { region: "Norte", value: 5 },
];

const topProducts = [
  { name: "Plano Pro", units: 320, revenue: "R$ 192.000", status: "em alta" },
  { name: "Curso Presencial", units: 140, revenue: "R$ 84.000", status: "estável" },
  { name: "Consultoria Premium", units: 65, revenue: "R$ 65.000", status: "alta demanda" },
];

const actions = [
  "Reforçar campanhas para Norte, aumentando o share em +5%",
  "Fazer follow-up com leads ativos para Consultoria Premium",
  "Oferecer cross-sell do Curso Presencial nos contratos Plano Pro",
];

function App() {
  const totalRevenue = useMemo(() => trendData.reduce((sum, item) => sum + item.revenue, 0), []);

  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">Dashboard de vendas</p>
          <h1>Performance comercial em tempo real</h1>
        </div>
        <div className="header-actions">
          <button className="ghost">Exportar relatório</button>
          <button className="primary">Atualizar dados</button>
        </div>
      </header>

      <section className="overview-grid">
        {overview.map((item) => (
          <article key={item.label} className="card">
            <div className="card-label">{item.label}</div>
            <p className="card-value">{item.value}</p>
            <span className={`card-delta ${item.tone}`}>{item.delta}</span>
          </article>
        ))}
      </section>

      <section className="charts-grid">
        <article className="card chart-card">
          <div className="card-title">
            <h2>Receita acumulada</h2>
            <span className="badge">Meta 102% concluída</span>
          </div>
          <div className="chart-wrapper">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
                <XAxis dataKey="month" stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#1f2937" }}
                  labelStyle={{ color: "#e2e8f0" }}
                />
                <Line type="monotone" dataKey="revenue" stroke="#14b8a6" strokeWidth={3} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="margin" stroke="#38bdf8" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="card-footer">
            <span>Receita total no semestre</span>
            <strong>{`R$ ${totalRevenue.toLocaleString("pt-BR")}`}</strong>
          </div>
        </article>

        <article className="card chart-card">
          <div className="card-title">
            <h2>Distribuição regional</h2>
          </div>
          <div className="chart-wrapper">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regionData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
                <XAxis dataKey="region" stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#1f2937" }}
                  labelStyle={{ color: "#e2e8f0" }}
                />
                <Bar dataKey="value" fill="#818cf8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="region-list">
            {regionData.map((region) => (
              <div key={region.region} className="region-item">
                <span>{region.region}</span>
                <strong>{region.value}%</strong>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="products-and-actions">
        <article className="card product-card">
          <div className="card-title">
            <h2>Top produtos e serviços</h2>
          </div>
          <div className="product-list">
            {topProducts.map((product) => (
              <div key={product.name} className="product-item">
                <div>
                  <p className="product-name">{product.name}</p>
                  <p className="product-meta">{product.units} unidades vendidas</p>
                </div>
                <div className="product-actions">
                  <p className="product-value">{product.revenue}</p>
                  <span className="badge amber">{product.status}</span>
                </div>
              </div>
            ))}
          </div>
        </article>

        <article className="card action-card">
          <div className="card-title">
            <h2>Ações recomendadas</h2>
          </div>
          <ul className="action-list">
            {actions.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </article>
      </section>
    </div>
  );
}

export default App;
